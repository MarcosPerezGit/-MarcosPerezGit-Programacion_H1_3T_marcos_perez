package paquete; // Esta clase pertenece al paquete llamado "paquete"

public class Main {
 public static void main(String[] args) {
     // Se crea una instancia de la clase MenuApp
     MenuApp app = new MenuApp();
     
     // Se llama al método que muestra el menú y permite interactuar con la aplicación
     app.mostrarMenu();
 }
}
